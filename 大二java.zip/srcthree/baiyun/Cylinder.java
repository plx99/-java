package baiyun;

public class Cylinder extends Circle{
private double height;
public double superficalArea()
{
  return 2*area()+girth()*height;	
}
public double volume()
{
return area()*height;	
}
}
