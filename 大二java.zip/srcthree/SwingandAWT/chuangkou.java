package SwingandAWT;
import java.awt.*;
import javax.swing.*;
public class chuangkou {
public static void main(String[] args) {
	JFrame f=new JFrame();
	f.setTitle("一个简单窗口");
	Container cp=f.getContentPane();
	cp.setLayout(new FlowLayout());
	cp.add(new JLabel("广东白云学院"));
	f.setSize(250,100);
	f.setBounds(100,100,250,100);
	f.pack();
	f.setVisible(true);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
