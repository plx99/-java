package 实训作业;



public class gg{
	public static void main(String[] args) {
		
	
	String str="sdhik|asdh|sadj|zxc|";
	String[] array=str.split("\\|");
	System.out.println("size:"+array.length);
	for(String at:array){
		System.out.println(at+",");
	}
}
}