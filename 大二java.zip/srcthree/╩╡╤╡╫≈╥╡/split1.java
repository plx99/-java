package 实训作业;

public class split1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    String string="sadjlsd,asdj,cbi,fjhk,  ,  ,";
    String[] strings=string.split(",",-1);
    System.out.println("size:"+strings.length);
    for(String st:strings ) {
    	System.out.println(st+",");
    }
	}

}
