package 实训作业;

public class Stu {
String name;
String sex;
public Stu(String na,String se) {
name=na;
sex=se;
}
public static void main(String arg[]) {
Stu s1=new Stu("Mary","F");

System.out.println("name:"+s1.name);

System.out.println("sex:"+s1.sex);

}

}

