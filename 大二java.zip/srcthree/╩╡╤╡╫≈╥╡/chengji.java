package 实训作业;

import java.util.*;
public class chengji {
public static void main(String arg[]){
 System.out.println("输入成绩:");
 Scanner in=new Scanner(System.in);
 int score=in.nextInt();
 if(score>=90&&score<=100){ 
System.out.println("该学生成绩等级为A！");
}else if(score>=60&&score<=89){
System.out.println("该学生成绩等级为B！");
}else if(score>=0&&score<60){
System.out.println("该学生成绩等级为C！");
}else{
System.out.println("输入有误！");
}
} 
}







