package 实训作业;

import java.awt.Container;
import java.awt.*;

import javax.swing.*;


public class lisan {
    JTextField pwdIn;
    JTextField pwdIn1;
    JTextField pwdIn2;
    JTextArea pwdShow;
    JButton btn;

    lisan(){
   JFrame f=new JFrame("梯形面积的计算");
   Container cp=f.getContentPane();
   f.setLayout(new FlowLayout());

        pwdIn=new JTextField(12);
        pwdIn1=new JTextField(12);

        JLabel j1=new JLabel("上底：");
        cp.add(pwdIn);
        JLabel j2=new JLabel("下底：");
        cp.add(pwdIn1);
        JLabel j3=new JLabel("高：");
        cp.add(pwdIn2);

        btn=new JButton("计算面积");
        cp.add(btn) ;
//        btn.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                JButton source=(JButton)e.getSource();
////                pwdShow.setText("梯形面积："+);
//            }
//        });
        f.setSize(330,300);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public static void main(String[] args) {
        new lisan();
     }
}
