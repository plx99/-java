package 实训作业;



public class dayin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int i,j,k;
		for(i=1;i<5;i++) {
			for(k=1;k<=8-2*i;k++) {
				System.out.print(" ");
			}
			for(j=1;j<=2*i-1;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		for(i=3;i>=1;i--) {
			for(j=1;j<=2*i-1;j++) {
				System.out.print("*");
			}
			
			for(k=1;k<=8-2*i;k++) {
				System.out.print(" ");
			}
			
			System.out.println();
		}
		
	}

}