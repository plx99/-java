package 实训作业;

public class 打印 {
	public static void main(String[] args) {
		//定义变量
		int k=6;
		int size=4;
		for (int i = 0; i < size; i++) {
			
			for (int j = 0; j < k-1-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < i+1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}


