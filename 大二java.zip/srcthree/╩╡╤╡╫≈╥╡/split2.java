package 实训作业;

public class split2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String wan="192:168:12:1";
        String[] wans=wan.split("\\:");
        System.out.println("size:"+wans.length);
        for(String st:wans) {
        	System.out.println(st+".");
        }
	}
}
