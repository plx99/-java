package 实训作业;

import java.awt.*;

import javax.swing.*;

import java.awt.event.*;



public class MenuDesign extends JFrame{

private String test = "";

private FileDialog openFile;

private JMenuBar jmb = new JMenuBar();

private JMenu mFile = new JMenu("File");

private JMenu mOption = new JMenu("Option");

private JMenu mHelp = new JMenu("Help");

private boolean moment = false;


private JMenuItem FOpen = new JMenuItem("Open...");

private JMenuItem FSave = new JMenuItem("Save");

private JMenuItem FClose = new JMenuItem("Close");

private JMenuItem FExit = new JMenuItem("Exit");

private JMenuItem OFont = new JMenuItem("Font...");

private JMenu OColor = new JMenu("Color...");

JCheckBox OAOT = new JCheckBox("Always On Top", true);

JRadioButton OS = new JRadioButton("Small", true);

JRadioButton OL = new JRadioButton("Large");


public MenuDesign() {

mFile.add(FOpen);

mFile.add(FSave);

mFile.add(FClose);

mFile.addSeparator();

mFile.add(FExit);


mOption.add(OFont);

mOption.add(OColor);

mOption.addSeparator();

mOption.add(OAOT);

mOption.addSeparator();

mOption.add(OS);

mOption.add(OL);


FOpen.setMnemonic('O');

FSave.setMnemonic('S');

FSave.setEnabled(moment);

FClose.setMnemonic('C');

FExit.setMnemonic('E');


FOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1,InputEvent.ALT_MASK));

FOpen.addActionListener(e->{

moment = true;

openFile = new FileDialog(this, "");

openFile.setVisible(true);

});

FExit.addActionListener(new a1());



jmb.add(mFile);

jmb.add(mOption);

jmb.add(mHelp);


this.setTitle("Menu Bemo");

this.setJMenuBar(jmb);

setLayout(null);

setBounds(0,0,400,300);

Container C = getContentPane();

JTextArea I = new JTextArea();

I.setBounds(1,208,1,33);

C.add(I);

OAOT.addActionListener(e->{

test = test + OAOT.getText();

I.setText(test);

});

this.setLocation(580,280);

this.setVisible(true);

}

class a1 implements ActionListener{

public void actionPerformed(ActionEvent e){

System.exit(0);

}

}

public static void main(String[] args) {

new MenuDesign();

   }

}



