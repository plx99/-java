package cn.binggo.javaclass;

public class Vehicle {
     private int speed;
     private int size;
	
public Vehicle() {
	speed=80;
	size=200;
}
public void setspeed(int spd) 
{
    speed=spd;
    System.out.println("Set speed!");
    System.out.println("Is moving at speed:"+speed);  
}
public void setspeedUp(int spdup) 
{
    speed=spdup;
    System.out.println("Speed Up!");
    System.out.println("Is moving at speed:"+speed);   
}
public void setspeedDown(int spdwn) 
{
    speed=spdwn;
    System.out.println("Speed Down!");
    System.out.println("Is moving at speed:"+speed);    
}
void display() 
{
System.out.println("Init speed:"+speed+","+"Size:"+size);
System.out.println("Is moving at speed:"+speed);
}
public static void main(String[] args) {
	Vehicle v1=new Vehicle();
	v1.display();
	v1.setspeed(120);
	v1.setspeedUp(240);
	v1.setspeedDown(235);
}
}
