package cn.binggo.javaclass;

public class Customer {
	String name;
	String age;
	String weight;
	String caozuo;
	public Customer() 
	{
		name="朱丽叶";
		age="28";
		weight="52千克";
		caozuo="购买商品";
	}
	public Customer(String na,String a,String wet,String cz) 
	{
		name=na;
		age=a;
		weight=wet;
		caozuo=cz;
	}
	public String getname() 
	{
		return name;
	}
	public void setname(String na) 
	{
		name=na;
	}
	
	public String getage() 
	{
		return age;
	}
	public void setage(String a) 
	{
		age=a;
	}
	
	public String weight() 
	{
		return weight;
	}
	public void setweight(String wet) 
	{
		weight=wet;
	}
	
	public String getcaozuo() 
	{
		return caozuo;
	}
	public void setcaozuo(String cz) 
	{
		caozuo=cz;
	}
	
	void display() {
		System.out.println("顾客：" );
		System.out.println("姓名：" + name);
		System.out.println("年龄：" + age);
		System.out.println("体重：" + weight);
		System.out.println("操作：" + caozuo);
		
	}
}
