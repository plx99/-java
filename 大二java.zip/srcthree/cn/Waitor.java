package cn.binggo.javaclass;
public class Waitor {
	String name;
	String zhiwei;
	String age;
	String weight;
	String caozuo;
	public Waitor() 
	{
		name="布兰尼";
		zhiwei="收银员";
		age="35";
		weight="60千克";
		caozuo="打印账单";
	}
	public Waitor(String na,String zw,String a,String wet,String cz) 
	{
		name=na;
		zhiwei=zw;
		age=a;
		weight=wet;
		caozuo=cz;
	}
	public String getname() 
	{
		return name;
	}
	public void setname(String na) 
	{
		name=na;
	}
	
	public String getzhiwei() 
	{
		return zhiwei;
	}
	public void setzhiwei(String zw) 
	{
		zhiwei=zw;
	}
	
	public String getage() 
	{
		return age;
	}
	public void setage(String a) 
	{
		age=a;
	}
	
	public String getweight() 
	{
		return weight;
	}
	public void setweight(String wet) 
	{
		weight=wet;
	}
	
	public String getcaozuo() 
	{
		return caozuo;
	}
	public void setcaozuo(String cz) 
	{
		caozuo=cz;
	}
	
	void dispaly() {
		System.out.println("员工：" );
		System.out.println("姓名：" + name);
		System.out.println("职务：" + zhiwei);
		System.out.println("年龄：" + age);
		System.out.println("体重：" + weight);
		System.out.println("操作：" + caozuo);
		
	}
}

