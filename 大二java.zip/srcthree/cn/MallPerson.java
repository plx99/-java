package cn.binggo.javaclass;


public class MallPerson {	
public static void main(String[] args) {
	Waitor w1=new Waitor();
	Customer c1=new Customer();
	w1.dispaly();
	c1.display();
}
}
