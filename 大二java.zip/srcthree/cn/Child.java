package cn.binggo.javaclass;

public class Child {
   private String name;
   private String age;
public Child(String na,String a) 
{
   name=na;
   age=a;
}
  void display() 
  {
	  System.out.println("Name:"+name+","+"Age:"+age);
  }
  public static void main(String[] args) {
	Child c1=new Child(	"Peter", "20");
	Child c2=new Child(	"Tom", "18");
	c1.display();
	c2.display();
}
}
