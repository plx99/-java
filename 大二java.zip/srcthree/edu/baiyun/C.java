package edu.baiyun.com;

public class C {
   public static void main(String[] args){
	   B ob=new B();
	   ob.f();
   }
}
