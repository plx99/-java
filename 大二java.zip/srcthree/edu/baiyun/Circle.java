package edu.baiyun.com;



	public class Circle {  private double radius;  public Circle()
	{
	radius = 1.0;
	}

	public Circle(double r)
	{
	radius = r;
	}
	public double girth()
	{
	return 2 * Math.PI * radius;
	}
	public double area()
	{
      return Math.PI*radius*radius;
}
	}
