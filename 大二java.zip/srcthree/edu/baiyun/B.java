package edu.baiyun.com;

public class B extends A{
	public int i=30;
	public void f(){
		super.f();
		System.out.println("i="+i);
	}

}
