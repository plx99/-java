package edu.baiyun.com;

public class A {
public int n=20;

public void f(){
	System.out.println("n="+n);
}
}
