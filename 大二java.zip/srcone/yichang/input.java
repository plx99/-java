package yichang;

import java.util.Scanner;

public class input {
	public static void inputScore(){
		   int score;
		   Scanner sc=new Scanner(System.in);
		    System.out.println("请输入成绩："); 
		    try {
		    score=sc.nextInt();
		    if(score<0 || score>100) 
		    	throw new ScoreException();
		    	else System.out.println("输入正确");
		    
		    }
		    catch(ScoreException e){
		    	System.out.println(e.toString());
		    }
		    catch(Exception e) {
		    	e.printStackTrace();
		    }
		    finally {
			System.out.println("input()执行结果");	
			}
	}	
	public static void main(String[] args) throws ScoreException{
		// TODO Auto-generated method stub
        inputScore();
	}
}
