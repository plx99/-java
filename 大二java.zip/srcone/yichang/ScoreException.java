package yichang;



public class ScoreException extends Exception {
  String cuowu;
public ScoreException() {
    cuowu="输入错误";
}
public ScoreException(String cuowo) {
	this.cuowu=cuowu;
}
public String toString() {
	return cuowu;
}
public String getMessage() {
	return cuowu+"成绩只能输入0~100";
}
}
