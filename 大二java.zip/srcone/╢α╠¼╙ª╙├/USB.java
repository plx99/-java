package 多态应用;

public interface USB {
    public void work();
    public void insert();
}
