package 多态应用;

public class MP3 implements USB {
    public String brand;
	public MP3() {
		this.brand="未知";
	}
	public MP3(String brand) {
		this.brand=brand;
	}
	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println(brand+"MP3在工作。");
     
	}

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		  System.out.println(brand+"MP3接入了USB接口。");
	}

}
