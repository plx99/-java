package samepackage;
import mainpackage.*;
public class Demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainSubClass M1=new	MainSubClass("《天才在左，疯子在右》");
		MainSubClass M2=new	MainSubClass(500);
		MainSubClass M3=new	MainSubClass("《天才在左，疯子在右》",500);
	}

}
