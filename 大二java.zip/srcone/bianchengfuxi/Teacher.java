package bianchengfuxi;

public class Teacher extends Person {
	   private String teaID;
	   public Teacher(){
	    	super();
	    	
	    }
	    public Teacher(String name,int age,String teaID){
	    	super(name,age);
	    	this.teaID=teaID;
	    }
	    public void setteaID(String teaID) {
	    	this.teaID=teaID;
	    }
	    public String getteaID() {
	    	return teaID;
	    }
	    public void live() {
	        System.out.println("老师住在自己家里或者教工宿舍");
	    }
	    public void teach() {
	        System.out.println("教师每天要备课、上课和批作业");
	    }
	}