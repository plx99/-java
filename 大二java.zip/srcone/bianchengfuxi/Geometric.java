package bianchengfuxi;

import java.util.Date;
import java.text.SimpleDateFormat;


public class Geometric {
	 private String color="white";
	 private boolean filled;
	 private Date dateCreated;
	public Geometric() {
		// TODO Auto-generated constructor stub
		 dateCreated=new Date();    
//	 	 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
//	     String hehe = df.format(dateCrDate); 
//	     System.out.println("当前系统时间："+hehe); 
	}
	 public Geometric(String color,boolean filled) {
	        this.color=color;
	        this.filled=filled;
	       dateCreated=new Date();    
//		 	 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
//		     String hehe = df.format(dateCrDate); 
//		     System.out.println("当前系统时间："+hehe); 
	 }
	public String getcolor() {
		 return color;
	 }
	 public void setcolor(String c) {
		 color=c;
	 }
	 public boolean getfilled() {
		 return filled;
	 }
	 public void setfilled(boolean f) {
		 filled=f;
	 }
	 public Date getdateCrDate() {
		 return dateCreated;
	 }
	 public String toString() {
		 return "Created on"+dateCreated+"  color:"+color+"   filled:"+filled;
	 }
	}
