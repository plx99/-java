package bianchengfuxi;


public class test {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Geometric geometric=new Geometric("red",true);
		
		System.out.println(geometric.toString());
        Circle circle=new Circle("yellow",false,2);
//       circle.setradius(5);
      
        System.out.println(circle.toString());
        System.out.println("周长："+circle.getPerimeter());
        System.out.println("面积："+circle.getArea());
        
}

}

