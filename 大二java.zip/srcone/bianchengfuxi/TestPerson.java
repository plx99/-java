package bianchengfuxi;

public class TestPerson {
public static void display(Person p) {
	p.live();
}
public static void showBehavior(Object obj) {
	if(obj instanceof Student) 
		((Student) obj).study();
	if(obj instanceof Teacher) 
	    ((Teacher) obj).teach();
		
}
public static void main(String[] args) {
	Person person=new Person("Sophia",30);
	Student student=new Student("Peter",20,"S001");
	Teacher teacher=new Teacher("Tom",40,"19111");
	
	display(person);
	display(student);
	display(teacher);
	showBehavior(person);
	showBehavior(student);
	showBehavior(teacher);
	}
}
