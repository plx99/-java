package bianchengfuxi;
public class Student extends Person {
    private String stuID;
    public Student(){
    	super();
    	
    }
    public Student(String name,int age,String stuID){
    	super(name,age);
    	this.stuID=stuID;
    }
    public void setStuID(String stuID) {
  	  this.stuID=stuID;
    }
    String getStuID() {
    	return stuID;
    }
    public void live() {
   	 System.out.println("学生住在多人的宿舍");
    }
    public void study() {
        System.out.println("学生每天要上课、学习和做作业");
    }
}