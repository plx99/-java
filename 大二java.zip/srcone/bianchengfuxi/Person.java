package bianchengfuxi;


public class Person{
	   private String name;
	   private int age;
	   public Person(){
	    	name="狗子";
	    	
	    }
	   public Person(String name,int age){
		   this.name=name;
		   this.age=age;
	   }
	   public void setname(String name) {
		   this.name=name;
		   
	   }
	   public String getname() {
		   return name;
	   }
	   public void setage(int age) {
		   this.age=age;
	   }
	   public int getage() {
		   return age;
	   }
	 public void live() {
		 System.out.println("每人都有居住的地方");
	 }
	}
