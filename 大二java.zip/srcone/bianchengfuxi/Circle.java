package bianchengfuxi;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Circle extends Geometric{
private double radius;
    public Circle(){
    radius=1;
    }
    public Circle(String color,boolean filled,double radius){
    	super(color,filled);
    	this.radius=radius;
    }
  
   public double getradius() {
	   return radius;
   }
   public void setradius(double radius) {
	   this.radius=radius;
   }
   public double getPerimeter() {
	   return 2*Math.PI*radius;
	   
   }
   public double getArea() {
	   return Math.PI*radius*radius;
   }
   public String toString() {
   return super.toString()+"\tradius:"+radius;
	
}
}
