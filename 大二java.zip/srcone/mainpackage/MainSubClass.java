package mainpackage;

public class MainSubClass extends MainClass{
    public MainSubClass(String name) {
		super(name);
	}
    
    public MainSubClass(int pagenumber) {
		super(pagenumber);
	}
    
    public MainSubClass(String name,int pagenumber) {
    	super(name, pagenumber);
		// TODO Auto-generated constructor stub
	}
}
