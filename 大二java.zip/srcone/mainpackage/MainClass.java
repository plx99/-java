package mainpackage;

public class MainClass {
    public String bookname;
    public int pagenumber;
    public MainClass(String name,int pagenumber) {
	    super();
	    this.bookname=name;
	    this.pagenumber=pagenumber;
	    System.out.println("书名："+name);
	    System.out.println("页数："+pagenumber);
	}
    
    public MainClass(String name) {
		super();
		this.bookname=name;
		 System.out.println("书名："+name);
	}
    
    public MainClass(int pagenumber) {
		super();
		this.pagenumber=pagenumber;
		System.out.println("页数："+pagenumber);
	}
}
