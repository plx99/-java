package cn.binggo.javafeatures.interfacetest;

public class Class4 implements Interface2 {
    String bookcontent;
	@Override
	public void write(String c) {
		// TODO Auto-generated method stub
        bookcontent=c;
        System.out.println("写入内容："+bookcontent);
	}

}
