package cn.binggo.javafeatures.interfacetest;

public class Class2 implements Interface1 {
	 
	@Override
	public void read() {
		// TODO Auto-generated method stub
	String bookname="十宗罪"; 
       System.out.println(bookname);
	}

}
