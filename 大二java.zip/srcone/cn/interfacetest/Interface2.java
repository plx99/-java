package cn.binggo.javafeatures.interfacetest;

public interface Interface2 {
	String content="未知";
    public abstract void write(String c);
}
