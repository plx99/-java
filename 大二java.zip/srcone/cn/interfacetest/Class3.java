package cn.binggo.javafeatures.interfacetest;

public class Class3 implements Interface1, Interface2 {
	String bookname1="天才在左，疯子在右"; 
	String bookname2="十宗罪"; 
	String bookname3; 
	@Override
	public void write(String c) {
		// TODO Auto-generated method stub
       bookname3=c;
       System.out.println(bookname3);
	}

	@Override
	public void read() {
		// TODO Auto-generated method stub
       System.out.println(bookname1);
       System.out.println(bookname2);
	}

}
