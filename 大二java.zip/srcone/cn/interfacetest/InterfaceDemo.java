package cn.binggo.javafeatures.interfacetest;

public class InterfaceDemo {

	public static void main(String args[]) {
		Class1 c1=new Class1();
		Class2 c2=new Class2();
		Class3 c3=new Class3();
		Class4 c4=new Class4();
		Class5 c5=new Class5();
		c1.read();
		c2.read();
		c3.write("时间简史");
		c3.read();
		c4.write("失败乃是成功之母");
		c5.manange();
		c5.write("01");
	}
}
