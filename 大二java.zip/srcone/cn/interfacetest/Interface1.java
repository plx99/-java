package cn.binggo.javafeatures.interfacetest;

public interface Interface1 {
   public abstract void read();
}
