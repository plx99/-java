package cn.binggo.javafeatures.interfacetest;

public class Class1 implements Interface1 {
	String bookname="天才在左，疯子在右"; 
	@Override
	public void read() {
		// TODO Auto-generated method stub
      System.out.println(bookname);
	}

}
