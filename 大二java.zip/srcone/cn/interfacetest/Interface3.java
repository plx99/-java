package cn.binggo.javafeatures.interfacetest;

public interface Interface3 {
    public abstract void manange();
}
