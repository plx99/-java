package cn.binggo.javafeatures.interfacetest;

public class Class5 implements Interface2, Interface3 {
    String booknumber;
	@Override
	public void manange() {
		// TODO Auto-generated method stub
      System.out.println("借出");
      System.out.println("归还");
	}

	@Override
	public void write(String c) {
		// TODO Auto-generated method stub
       booknumber=c;
       System.out.println("写入图书编号："+booknumber);
	}

}
