package cn.binggo.javafeatures;

public class Son extends Father{
	
	public Son(String house) {
		super(house);
    	System.out.println("房子："+house);
    }
	
	public static void main(String[] args) {
	Son s1=new Son("商品房");
	
}
}
