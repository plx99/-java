package cn.binggo.javafeatures.interfacedemo;

public class Helicopter implements FlyWeapon {

	public void fight() {
		// TODO Auto-generated method stub
         System.out.println("开火");
	}

	public void land() {
		// TODO Auto-generated method stub
		System.out.println("着落");
	}

	public void speedDown() {
		// TODO Auto-generated method stub
		System.out.println("减速");
	}

	public void speedUp() {
		// TODO Auto-generated method stub
		System.out.println("加速");
	}

	public void startFly() {
		// TODO Auto-generated method stub
		System.out.println("起飞");
	}
    public static void main(String args[]){
    	Helicopter h=new Helicopter();
    	h.speedUp();
    	h.speedDown();
    }
}
