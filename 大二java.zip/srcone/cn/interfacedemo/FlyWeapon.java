package cn.binggo.javafeatures.interfacedemo;

public interface FlyWeapon {
    int weight=100000;
    int flyRange=500;
    int capacity=50000;
    public abstract void startFly();
    public abstract void speedUp();
    public abstract void speedDown();
    public abstract void fight();
    public abstract void land();
}
