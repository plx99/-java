package cn.binggo.javafeatures;

public class Father {
    String house;
    private String watch;
    
	public Father(String house,String watch) {
		super();
		this.house=house;
		this.watch=watch;
	}
	
	public Father(String house) {
		super();
		this.house=house;
	}
	
	public Father() {
		super();
	}
}
