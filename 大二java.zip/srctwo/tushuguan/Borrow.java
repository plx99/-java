package tushuguan;

public class Borrow {
private String borrowerid;
private String borrowerdate;
private String bookname;
private String returndate;
public Borrow(String id,String bd,String bna,String rd) 
{
      borrowerid=id;
      borrowerdate=bd;
      bookname=bna;
      returndate=rd;
	// TODO Auto-generated constructor stub
}
public String getborrowerid() {
	return borrowerid;
}
public void setborrowerid(String id) 
{
     borrowerid=id;	
}

public String getborrowdate() {
	return borrowerdate;
}
public void setborrowdate(String bd) 
{
     borrowerdate=bd;	
}

public String getbookname() {
	return bookname;
}
public void setbokname(String bn) 
{
     bookname=bn;	
}

public String getreturndate() {
	return returndate;
}
public void setreturndate(String rd) 
{
     returndate=rd;	
}

}