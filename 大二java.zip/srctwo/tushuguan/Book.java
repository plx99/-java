package tushuguan;

public class Book {
	private String author;
	private String bookname;
	private String publisher;
	private String price;
	private String isbn;
	private String bookid;
	public Book() {
		bookid ="000000";
		bookname="未知";
		author="未知";
		publisher="未知出版社";
		price="0";
		isbn="0000000000";		
	}
	public Book(String bid,String au,String pub,String pri,String i,String bn) {
		bookid=bid;
		bookname=bn;
		author=au;
		publisher=pub;
		price=pri;
		isbn=i;
	}
	public String getBookId()
	{
		return bookid;
	}
	public void setBookId(String bid) 
	{
		bookid=bid;
	}
	
	public String getBookname()
	{
		return bookname;
	}
	public void setBookname(String bn) 
	{
		bookname=bn;
	}
	
	public String getauthor()
	{
		return author;
	}
	public void setauthor(String au) 
	{
		bookid=au;
	}
	public String getPublisher()
	{
		return publisher;
	}
	public void setPublisher(String pub) 
	{
		publisher=pub;
	}
	public String getPrice()
	{
		return price;
	}
	public void setPrice(String pri) 
	{
		price=pri;
	}
	public String getIsbn()
	{
		return isbn;
	}
	public void setIsbn(String i) 
	{
		isbn=i;
	}
}
