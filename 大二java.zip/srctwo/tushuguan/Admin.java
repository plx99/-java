package tushuguan;

public class Admin {
     private String adminid;
     private String adminname;
public Admin() 
{
   adminid="未知";
   adminname="未知";
}
public Admin(String id,String an) 
{
   adminid=id;
   adminname=an;
}
public String getadminid() 
{
   return adminid;
}
public void setadminid(String id)
{
	adminid=id;
}

public String getadminname() 
{
   return adminname;
}
public void setadminname(String an)
{
	adminname=an;
}
}
