package tushuguan;

public class Reader {
    private String readername;
    private String readerid;
    private String department;
public Reader() 
{
    readername="未知";
    readerid="未知";
    department="未知";
}
public Reader(String rn,String rid,String ment) 
{
   readername=rn;
   readerid=rid;
   department=ment;
}
public String getreadername() {
	return readername;
}
public void setreadername(String rn) {
	readername=rn;
}

public String getreaderid() {
	return readerid;
}
public void setreaderid(String rid) {
	readerid=rid;
}

public String getdepartment() {
	return department;
}
public void setdepartment(String ment) {
	department=ment;
}
}
