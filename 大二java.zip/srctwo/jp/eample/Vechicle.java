package jp.eample.javabase;
public class Vechicle {
	void run() {
		System.out.println("guangdongsheng");
	}
	static class she extends Vechicle{
		void run() {
			System.out.println("enpingshi");
		}
	}
public static void main(String[] args) {
			// TODO Auto-generated method stub
	she m1= new she();
	m1.run();
		}

	}
	
