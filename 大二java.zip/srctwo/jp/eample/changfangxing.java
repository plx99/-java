package jp.eample.javabase;
import java.util.*;
public class changfangxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("你好，请输入长方形的长：");
		Scanner sc = new Scanner(System.in);
       int longs= sc.nextInt();
       System.out.println("你好，请输入长方形的宽");
		Scanner sc1 = new Scanner(System.in);
        int wides = sc.nextInt();
        int area,zhouchang;
        area=longs*wides;
        zhouchang=2*longs+2*wides;
        System.out.println("长方形的面积:"+area);
        System.out.println("长方形的周长:"+zhouchang);
	}

}
