package jp.eample.javabase;
class Adders{
	static int add(int a, int b) {
		return a + b;
	}
	static double add(double a,double b) {
		return a + b;
	}
}
public class TestOverloading2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(Adders.add(67,98));
System.out.println(Adders.add(23.1, 23.9));
	}

}
