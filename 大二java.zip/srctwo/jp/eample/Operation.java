package jp.eample.javabase;

class Operation {
    int data = 50;

    void change(int data) {
        this.data = data + 100;// changes will be in the local variable only
    }

    public static void main(String args[]) {
        Operation op = new Operation();

        System.out.println("before change " + op.data);
        op.change(500);
        System.out.println("after change " + op.data);

    }
}//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/call-by-value-and-call-by-reference-in-java.html


