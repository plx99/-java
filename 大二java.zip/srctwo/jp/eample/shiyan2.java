package jp.eample.javabase;

public class shiyan2 {
String a="jie";
}
class shiyan3 extends shiyan2 {
	String b="peng";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
shiyan3 n =new shiyan3();
System.out.println(n.a);
System.out.println(n.b);
	}

}
