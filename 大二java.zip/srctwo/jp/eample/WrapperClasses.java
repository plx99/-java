package jp.eample.javabase;
import java.util.ArrayList;
import java.util.List;//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/wrapper-class-in-java.html


public class WrapperClasses {

    private static void doSomething(Object obj){

    }

    public static void main(String args[]){
        int i = 10;
        char c = 'a';

        // 原始数据很容易使用
        int j = i+3;

        // 由包装类实现的多态性，不能在这里传递原始数据
        doSomething(new Character(c));

        List<Integer> list = new ArrayList<Integer>();
        // 包装类可以在集合中使用
        Integer in = new Integer(i);
        list.add(in);

        // 自动装箱负责原始到包装器类的转换
        list.add(j);

        //包装类可以为 null
        in = null;
    }
}//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/wrapper-class-in-java.html

