package jp.eample.javabase;
import java.util.*;
public class example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int radius[]=new int[5];
double area[]=new double[5];
Scanner sc=new Scanner(System.in);
System.out.println("请输入一组半径:");
for(int i=0;i<radius.length;i++) {
	int r=sc.nextInt();
	radius[i]=r;
	area[i]=r*r*Math.PI;
}
for(int j = 0; j < 5; j++) {
    System.out.println("半径为：" + radius[j] + "的圆的面积是：" + area[j]);
	}
	}
}
