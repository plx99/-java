package jp.eample.javabase;
interface Shape {

    public void draw();
}//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/java-oops-concepts.html

class Circle implements Shape{

    @Override
    public void draw(){
        System.out.println("绘制圆形");
    }
}//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/java-oops-concepts.html

class Square implements Shape {

    @Override
    public void draw() {
        System.out.println("绘制长方形");
    }

}//原文出自【易百教程】，商业转载请联系作者获得授权，非商业请保留原文链接：https://www.yiibai.com/java/java-oops-concepts.html


public class shiyan1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape sh = new Square();
        sh.draw();

        
    
	}

}
