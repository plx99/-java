package jp.eample.javabase;

public class shuzi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
