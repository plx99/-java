package jp.eample.javabase;

public class Student1 {
int age;
String name;
static String college = "ITS";

static void change() {
	college ="ABC";
}
Student1(int i,String a){
	age = i;
	name = a;
}
void display() {
	System.out.print(age+" "+name+" "+college);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student1.change();
Student1 s1 = new Student1(11,"jx");
s1.display();

	}

}
