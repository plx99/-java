package cn.binggo.javabase;

public class CycleDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1,sum = 0;
while(i<=9)
{sum +=i;
 i +=2;
	}
System.out.print(sum);
	}

}
