package cn.binggo.javabase;

public class DataType {
public static void main(String[] args) {
//	TOOD Auto-generated methed stub
	double y=12.5;
	 int x;
	 x=(int)y;
	 System.out.println("x��ֵ�ǣ�"+x);
}
}
