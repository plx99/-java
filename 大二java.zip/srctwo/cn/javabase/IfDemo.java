package cn.binggo.javabase;
import java.util.*;
public class IfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("你好，请输入你的成绩");
		Scanner sc = new Scanner(System.in);
int score = sc.nextInt();
if( score >= 60 )
{
	System.out.println("成绩合格");
sc.close();
}

}

}
