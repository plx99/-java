package cn.binggo.javabase;
import java.util.Scanner;
public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("请输入你的成绩：");
		int score =sc.nextInt();
		switch(score/10)
	    {
	    case 10:  //100分
	    case 9:   //90-99分
	    	System.out.println("A\n");
	    	break;
	    case 8:   //80-89分
	    	System.out.println("B\n");
	        break;
	    case 7:
	    	System.out.println("C\n");
	        break;
	    case 6:
	    	System.out.println("D\n");
	        break;
	    default :
	    	System.out.println("E\n");
	    }
	   
	}

	}


