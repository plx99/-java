package cn.binggo.javabase;

public class CycleDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 1;i<=8;i++)
		{
			
			System.out.println("我爱您，中国！");
	}
}
}
