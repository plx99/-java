package cn.binggo.javabase;
import java.util.Scanner;
public class IfElseIfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.println("请输入你的成绩：");
int score =sc.nextInt();
if( score >= 90 )
	System.out.println("你的成绩：A");
else if( 89>=score && score >= 80 )
	System.out.println("你的成绩：B");
else if( 79>=score && score >= 70 )
	System.out.println("你的成绩：C");
else if( 69>=score && score >= 60 )
	System.out.println("你的成绩：D");
else
	System.out.println("你的成绩：E");
	}

}
