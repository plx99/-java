package cn.binggo.javabase;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class StandardIO2 {
public static void main(String[] args) {
try{
	//输入流，从键盘接收数
	InputStreamReader isr = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);
	//提示输入数据
	System.out.println("请输入第一个数：");
	//从控制台读取一行数据
	String a1 = br.readLine();
	System.out.println("请输入第二个数：");
	String a2 = br.readLine();
	//String转float
	float num1 = Float.parseFloat(a1);
	float num2 = Float.parseFloat(a2);
	float sum = num1 + num2;
	System.out.print("这两个数相加的结果是：" + sum);

	} catch (Exception e) {
		e.printStackTrace();
	}
}
}
