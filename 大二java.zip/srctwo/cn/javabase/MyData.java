package cn.binggo.javabase;
import java.util.Scanner;
public class MyData {
	public static void main (String[] args){
		Scanner input = new Scanner(System.in);
		System.out.println("请输入一个整数");
		int sum;
		sum = input.nextInt();
		
		if( sum%2 == 0) 
		{
			System.out.println("该数是偶数");
		}
		else {
			System.out.println("该数是奇数");
		}
		}
		}


