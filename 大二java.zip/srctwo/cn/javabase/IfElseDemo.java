package cn.binggo.javabase;

import java.util.Scanner;

public class IfElseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("你好，请输入你的成绩");
		Scanner sc = new Scanner(System.in);
int score = sc.nextInt();
if( score >= 60 )
{
	System.out.println("恭喜你，你的成绩已合格，不用补考！");
	sc.close();
	}
else
{
	System.out.println("不好意思，你的成绩不及格，不用补考！");
	sc.close();	
}
}

}
