package cn.binggo.javabase;

public class CharCase {
	public static void main (String[] args) {
	char c1=80;
	char c2='a';
	System.out.println("c1+c2="+c1+c2);
	}
	}

