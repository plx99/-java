package cn.binggo.javabase;
import java.util.Scanner;
public class StudentScore1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int score[]=new int[5];
String range[]=new String[5];
Scanner sc =new Scanner(System.in);
for(int i = 0; i < score.length; i++)
{   
	System.out.println("第"+(i+1)+"个成绩是");
	score[i]= sc.nextInt();
			}
for(int i =0;i<score.length;i++) {
switch(score[i]/10) {
case 10:
case 9:
	range[i] = "优秀";
	break;
case 8:
	range[i] = "良好";
	break;
case 7:
	range[i] ="及格";
	break;
case 6:
	range[i] ="不及格";
}
}
for(int i=0;i<score.length;i++)
	System.out.print(score[i] + " ");
System.out.println();
for(int i =0;i<range.length;i++) 
	System.out.print(range[i] +" ");
sc.close();
}
}