package cn.binggo.javabase;
import java.io.*;

public class StandardIO {
public static void main(String args[]) throws IOException{
	char c;
	System.out.println("请输入一个单词：");
	c=(char)System.in.read();
	System.out.println("你输入的单词的首字母："+c);
	c=(char)System.in.read();
	System.out.println("你输入的单词的第二字母："+c);
	c=(char)System.in.read();
	System.out.println("你输入的单词的第二字母："+c);
	
}
}
