package cn.binggo.array;

public class DepositReceipts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
