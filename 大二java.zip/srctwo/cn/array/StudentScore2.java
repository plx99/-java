package cn.binggo.array;
import java.util.Scanner;
public class StudentScore2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int score[][]=new int[5][2];
String range[][]=new String[5][2];
Scanner sc =new Scanner(System.in);
	for(int i=0;i<score.length;i++) {
	for(int j=0;j<score[i].length;j++) {
	System.out.print("请输入第"+ (i+1)+"个学生的第"+ (j+1)+"个成绩：");
	score[i][j]=sc.nextInt();
	}
	}
	for(int i=0;i<score.length;i++) {
	for(int j=0;j<score[i].length;j++) {
		switch(score[i][j]/10) {
		case 10:
		case 9:
			range[i][j]="优秀";
			break;
		case 8:
	        range[i][j]="良好";
	        break;
		case 7:
		case 6:
			range[i][j]="及格";
			break;
			default:
				range[i][j]="不及格";
				
		}
		
	}
	}
	System.out.println("第一个同学2个成绩"+score[0][0]+" "+range[0][0]+" "+score[0][1]+" "+range[0][1]);
	System.out.println("第二个同学2个成绩"+score[1][0]+" "+range[1][0]+" "+score[1][1]+" "+range[1][1]);
	System.out.println("第三个同学2个成绩"+score[2][0]+" "+range[2][0]+" "+score[2][1]+" "+range[2][1]);
	System.out.println("第四个同学2个成绩"+score[3][0]+" "+range[3][0]+" "+score[3][1]+" "+range[3][1]);
	System.out.println("第五个同学2个成绩"+score[4][0]+" "+range[4][0]+" "+score[4][1]+" "+range[4][1]);
	System.out.println();
	sc.close();
	}
	}


