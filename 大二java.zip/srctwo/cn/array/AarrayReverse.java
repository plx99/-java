package cn.binggo.array;
import java.util.*;
public class AarrayReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int arrayList[] = new int[];
System.out.println("请输入7个整数：");
for(int i=0;i<arrayList.length;i++) {
	arrayList[i]=sc.nextInt();
}
System.out.println("反转前排序：" + arrayList);
Collections.reverse(arrayList);
System.out.print("反转后排序：" + arrayList);

	}

}
