package cn.binggo.array;

public class ArrayDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] nums =new int[] {61,23,4,74,13,148,20};
int max = nums[0];
int min = nums[0];
double sum = 0;
double avg = 0;
for(int i=0;i<nums.length;i++) {
	if(nums[i]>max)
	{
		max=nums[i];
	}
}
for(int i=0;i<nums.length;i++) {
	if(nums[i]<min)
	{
		min=nums[i];
	}
}
for(int i=0;i<nums.length;i++) {
	sum +=nums[i];
}
avg=sum/7;
System.out.println("数组的和："+sum);
System.out.println("最大值："+max);
System.out.println("最小值："+min);
System.out.println("平均值："+avg);
	}

}
