package cn.binggo.array;
import java.util.Scanner;
import java.util.Arrays;
public class ScoreSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int score[] =new int[10];
Scanner sc=new Scanner(System.in);
System.out.println("请输入某门课的10个成绩：");
for(int i=0;i<score.length;i++) {
	System.out.print("第"+(i+1)+"个成绩是：");
	score[i]=sc.nextInt();
}
System.out.println("成绩由低到高的排序结果：");
Arrays.sort(score);
for(int i:score) 
{
System.out.print(i+"\t");
 }
	}

}
