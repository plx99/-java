package cn.binggo.array;
import java.util.*;
public class ArraysEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ary[];
int ary1[];
int ary2[];
ary=new int[] {1,3,5,7,9};
ary1=new int[] {1,3,5,7,9};
ary2=new int[] {1,3,5,7,9,10};
System.out.println("数组ary是否与数组ary1相等："+Arrays.equals(ary,ary1));
System.out.println("数组ary1是否与数组ary2相等："+Arrays.equals(ary1,ary2));
	}

}
