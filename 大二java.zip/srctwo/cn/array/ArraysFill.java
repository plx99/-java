package cn.binggo.array;
import java.util.*;
public class ArraysFill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str[]=new String[1];
String str1[]=new String[1];
String str2[]=new String[1];
String str3[]=new String[1];
String str4[]=new String[1];
String str5[]=new String[1];
Arrays.fill(str,"I love China!");
for(String i:str)
		System.out.println(i);
Arrays.fill(str1,"I love China!");
for(String i:str1)
		System.out.println(i);
Arrays.fill(str2,"I love China!");
for(String i:str2)
		System.out.println(i);
Arrays.fill(str3,"I love China!");
for(String i:str3)
		System.out.println(i);
Arrays.fill(str4,"I love China!");
for(String i:str4)
		System.out.println(i);
Arrays.fill(str5,"I love China!");
for(String i:str5)
		System.out.println(i);
	}

}
